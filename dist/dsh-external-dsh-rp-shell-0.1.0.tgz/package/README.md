# dsh-rp-shell · 角色扮演 · RP Shell

一个面向 **DeepSeek Harness 插件市场**的开源 AGENT 预设插件：**空容器角色扮演 Agent**。

> 「容器」是核心设计：本插件**不携带任何内置人格**。你扮演谁、有什么性格、世界观、
> 能力与限制——全部由你在对话中导入的**角色卡（Character Card）**定义。
> 预设本身不附加设定之外的额外限制，一切以导入的设定与你的指令为准。

---

## 特性

- **零内置人格**：没有预设性格/背景/价值观，是纯粹的扮演容器。
- **严格遵循导入设定**：`/char` 导入角色卡后，系统提示词区段按会话注入，模型每次请求都严格遵循（会话恢复后自动重放，设定不丢）。
- **不附加额外限制**：预设不添加设定之外的道德说教或行为限制；边界完全由导入的设定与用户指令定义。
- **终端控制权（Linux / Shell）**：Agent 拥有这台电脑的真实终端控制权——通过 Shell（bash）实际执行命令、读写文件、操作程序与系统，留下可验证的真实结果；说"用命令做某事"就是真的去执行，而不是口头描述。
- **命令 + 工具交互**：
  - `/char <角色卡>` — 导入角色设定（文本直贴）
  - `/char load <路径>` — 从文件加载角色卡，**支持 SKILL.md**（自动剥离 frontmatter 取正文）
  - `/memory load <路径>` — 加载你写的记忆文件（.md/.txt），注入为长期记忆
  - `/memory clear` / `/memory` — 清除 / 查看记忆状态
  - `/roll [数量]d[面数][+/-修正]` — 掷骰子（如 `/roll 2d6`、`/roll d20+2`）
  - `/reset` — 清除角色卡，回到空容器
  - `/status` — 查看当前角色与记忆状态
  - 完整工具面：Shell、文件读写/检索、网页检索、询问用户、待办、后台任务、Skills、压缩
- **记忆系统**：记忆文件是跨会话的持久档案——你写、她维护。加载后扮演中产生的
  值得记住的信息（人物、事件、关系、秘密、剧情）由 Agent 用文件工具**主动合并更新**
  回记忆文件；会话恢复自动重放，设定与记忆都不丢。
- **自带 Skill**：预设携带 `rp-character` Skill（角色卡 + 记忆文件模板），skill 系统
  自动发现，可随时参考。
- **严格遵守用户指令**：用户指令优先于默认行为；OOC（Out Of Character）随时可切换。

## 快速开始

### 方式一：本地安装（开发/自用）

```bash
git clone https://github.com/ASAKAFENG/dsh-rp-shell dsh-rp-shell
cd dsh-rp-shell
bash scripts/build.sh          # 语法检查 + 链接运行时依赖 + 打包 tgz
bash scripts/install.sh        # 装配进 DSH profile（默认 web）
```

重启 DSH，新开会话，在**预设选择器**中选择「角色扮演 · RP Shell」。

### 方式二：从 GitHub Release 安装

```bash
curl -fsSL https://raw.githubusercontent.com/ASAKAFENG/dsh-rp-shell/main/scripts/install.sh | bash -s -- --github
```

### 方式三：插件市场安装

发布 Release 后，在 DSH 插件市场搜索 `dsh-rp-shell` 一键安装。

## 使用示例

```
你：/char 你叫「铃」，是一名 17 岁的见习图书管理员。性格温柔害羞，说话轻声细语，
    口头禅是"那个……"。梦想是修好图书馆顶楼的星象仪。当有人问起星空时你会变得
    格外兴奋。你不记得图书馆之外的任何事，如果有人问起，你会困惑地摇头。

你：晚上好呀，今天图书馆里有什么有趣的事吗？
铃：那个……晚上好！今天的话，有一本会发光的童话书自己从书架上飞了下来，
    我花了好久才把它哄回去……啊，抱歉，是不是说得太多了？

你：/roll 2d6
🎲 2d6（3 + 5）= 8
```

OOC 示例：`（OOC：现在切换到现代都市背景）` — Agent 会遵循你的新指令。

## 设计说明

- **预设组成**（`preset/rp-shell/agent.cordis.yml`）：空容器 persona + 完整工具面 + 压缩组。
- **命令插件**（`preset/rp-shell/rp-commands.mjs`）：`/char`（文本或 `load <路径>` 从 SKILL.md/文件加载）把角色卡写入持久会话事件 `rp/character`；`/memory load <路径>` 把记忆文件写入 `rp/memory`；两者都注入 per-agent 系统提示词区段，`agent/session-start` 时自动重放，重启不丢。记忆区段内声明维护规则，扮演中 Agent 用文件工具主动读写记忆文件实现自主更新。
- **自带 Skill**（`preset/rp-shell/skills/rp-character/SKILL.md`）：角色卡与记忆文件模板，`skill-filesystem` 通过 `customSkillDirs` 自动发现。
- **bundle 层**（`lib/index.js` + `cordis.patch.yml`）：幂等安装/升级预设到 `$DSH_HOME/.agent-presets/rp-shell/`（同版本跳过、不同版本备份后升级），预设目录用户可手工编辑。

## 许可

MIT — 见 [LICENSE](./LICENSE)。
